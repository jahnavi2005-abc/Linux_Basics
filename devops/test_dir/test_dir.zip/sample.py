# simple arithmetic in Python

# addition
a = 10
b = 5
print("Sum:", a + b)

# subtraction
print("Difference:", a - b)

# multiplication
print("Product:", a * b)

# division
print("Quotient:", a / b)
